// Mock Company Data
const companies = [];

// Add Company
document.getElementById('company-form').onsubmit = function (e) {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const location = document.getElementById('location').value;
    const linkedin = document.getElementById('linkedin').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const comments = document.getElementById('comments').value;
    const periodicity = document.getElementById('periodicity').value;

    const newCompany = {
        name,
        location,
        linkedin,
        email,
        phone,
        comments,
        periodicity,
        lastCommunication: new Date().toLocaleDateString(),
        nextCommunication: calculateNextDate(periodicity)
    };

    companies.push(newCompany);
    updateDashboard();
    clearForm();
};

// Update Dashboard
function updateDashboard() {
    const tbody = document.querySelector('#company-table tbody');
    tbody.innerHTML = '';

    companies.forEach(company => {
        const row = `<tr>
            <td>${company.name}</td>
            <td>${company.location}</td>
            <td>${company.email}</td>
            <td>${company.phone}</td>
            <td>${company.lastCommunication}</td>
            <td>${company.nextCommunication}</td>
        </tr>`;
        tbody.innerHTML += row;
    });

    populateCalendar();
}

// Populate Calendar
function populateCalendar() {
    const calendar = document.querySelector('.calendar-grid');
    calendar.innerHTML = '';

    for (let i = 1; i <= 30; i++) {
        const div = document.createElement('div');
        div.textContent = i;

        const today = new Date().getDate();
        if (i === today) {
            div.classList.add('today');
        }
        
        companies.forEach(company => {
            if (new Date(company.nextCommunication).getDate() === i) {
                div.classList.add('overdue');
            }
        });

        calendar.appendChild(div);
    }
}

// Calculate Next Communication Date
function calculateNextDate(days) {
    const currentDate = new Date();
    currentDate.setDate(currentDate.getDate() + parseInt(days));
    return currentDate.toLocaleDateString();
}

// Clear Form Fields
function clearForm() {
    document.getElementById('company-form').reset();
}
