import React from 'react'

export default function Form() {
  return (
    <div className='mt-[2rem]'>
      <form className="max-w-2xl mx-auto p-6 bg-white rounded-md shadow-md">
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Company Information</h2>
        <div className="grid grid-cols-1 gap-6">
          <div className="flex items-center">
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 w-1/3">Name</label>
            <input
              type="text"
              id="name"
              name="name"
              placeholder="Enter your Name"
              className="mt-1 block w-2/3 rounded-md border-black shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div className="flex items-center">
            <label htmlFor="location" className="block text-sm font-medium text-gray-700 w-1/3">Location</label>
            <input
              type="text"
              id="location"
              name="location"
              placeholder="Enter your Location"
              className="mt-1 block w-2/3 rounded-md border-black shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div className="flex items-center">
            <label htmlFor="linkedin" className="block text-sm font-medium text-gray-700 w-1/3">LinkedIn Profile</label>
            <input
              type="url"
              id="linkedin"
              name="linkedin"
              placeholder="Enter your LinkedIn Profile URL"
              className="mt-1 block w-2/3 rounded-md border-black shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div className="flex items-center">
            <label htmlFor="emails" className="block text-sm font-medium text-gray-700 w-1/3">Emails</label>
            <input
              type="email"
              id="emails"
              name="emails"
              placeholder="Enter your Email"
              className="mt-1 block w-2/3 rounded-md border-black shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div className="flex items-center">
            <label htmlFor="phone-numbers" className="block text-sm font-medium text-gray-700 w-1/3">Phone Numbers</label>
            <input
              type="tel"
              id="phone-numbers"
              name="phone-numbers"
              placeholder="Enter your Phone Number"
              className="mt-1 block w-2/3 rounded-md border-black shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div className="flex items-center">
            <label htmlFor="comments" className="block text-sm font-medium text-gray-700 w-1/3">Comments</label>
            <textarea
              id="comments"
              name="comments"
              rows="3"
              placeholder="Enter your Comments"
              className="mt-1 block w-2/3 rounded-md border-black shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            ></textarea>
          </div>
          <div className="flex items-center">
            <label htmlFor="communication-periodicity" className="block text-sm font-medium text-gray-700 w-1/3">Communication Periodicity</label>
            <select
              id="communication-periodicity"
              name="communication-periodicity"
              className="mt-1 block w-2/3 rounded-md border-black shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            >
              <option>Every week</option>
              <option>Every 2 weeks</option>
              <option>Every month</option>
            </select>
          </div>
        </div>
        <div className="mt-6 flex justify-end">
          <button
            type="submit"
            className="inline-flex justify-center rounded-md border border-transparent bg-indigo-600 py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  )
}
