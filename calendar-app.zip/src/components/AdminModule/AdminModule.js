import React, { useState } from 'react';
import './AdminModule.css'

// Admin Module Component
export default function AdminModule() {
  const [companies, setCompanies] = useState([]);
  const [methods, setMethods] = useState([
    { name: 'LinkedIn Post', description: 'Post on LinkedIn', sequence: 1, mandatory: true },
    { name: 'LinkedIn Message', description: 'Message on LinkedIn', sequence: 2, mandatory: true },
    { name: 'Email', description: 'Send an email', sequence: 3, mandatory: true },
    { name: 'Phone Call', description: 'Call the company', sequence: 4, mandatory: true },
    { name: 'Other', description: 'Other communication method', sequence: 5, mandatory: false },
  ]);

  const [newCompany, setNewCompany] = useState({
    name: '',
    location: '',
    linkedIn: '',
    emails: '',
    phoneNumbers: '',
    comments: '',
    periodicity: ''
  });

  const addCompany = () => {
    setCompanies([...companies, { ...newCompany }]);
    setNewCompany({
      name: '',
      location: '',
      linkedIn: '',
      emails: '',
      phoneNumbers: '',
      comments: '',
      periodicity: ''
    });
  };

  const deleteCompany = (index) => {
    const updatedCompanies = companies.filter((_, i) => i !== index);
    setCompanies(updatedCompanies);
  };

  return (
    <div className="admin-module">
      <h1>Admin Module</h1>

      {/* Company Management */}
      <h2>Company Management</h2>
      <div className="company-form">
        <input type="text" placeholder="Name" value={newCompany.name} onChange={(e) => setNewCompany({ ...newCompany, name: e.target.value })} />
        <input type="text" placeholder="Location" value={newCompany.location} onChange={(e) => setNewCompany({ ...newCompany, location: e.target.value })} />
        <input type="text" placeholder="LinkedIn Profile" value={newCompany.linkedIn} onChange={(e) => setNewCompany({ ...newCompany, linkedIn: e.target.value })} />
        <input type="text" placeholder="Emails" value={newCompany.emails} onChange={(e) => setNewCompany({ ...newCompany, emails: e.target.value })} />
        <input type="text" placeholder="Phone Numbers" value={newCompany.phoneNumbers} onChange={(e) => setNewCompany({ ...newCompany, phoneNumbers: e.target.value })} />
        <input type="text" placeholder="Comments" value={newCompany.comments} onChange={(e) => setNewCompany({ ...newCompany, comments: e.target.value })} />
        <input type="text" placeholder="Communication Periodicity" value={newCompany.periodicity} onChange={(e) => setNewCompany({ ...newCompany, periodicity: e.target.value })} />
        <button onClick={addCompany}>Add Company</button>
      </div>

      <ul>
        {companies.map((company, index) => (
          <li key={index}>
            {company.name} - {company.location} - {company.linkedIn}
            <button onClick={() => deleteCompany(index)}>Delete</button>
          </li>
        ))}
      </ul>

      {/* Communication Methods Management */}
      <h2>Communication Methods</h2>
      <ul>
        {methods.map((method, index) => (
          <li key={index}>
            {method.sequence}. {method.name} - {method.description} (Mandatory: {method.mandatory ? 'Yes' : 'No'})
          </li>
        ))}
      </ul>
    </div>
  );
}
