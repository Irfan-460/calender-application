// User Module Component
import './UserModule.css'
export default function UserModule() {
    return (
      <div className="user-module">
        <h1>User Dashboard</h1>
        <h2>Company Communications</h2>
        {/* Dashboard and Notification Section */}
        <div className="dashboard">
          <p>Grid View: Company Details, Last 5 Communications, and Next Scheduled Communication</p>
          <p>Color Codes: Red (Overdue), Yellow (Due Today)</p>
        </div>
  
        <h2>Notifications</h2>
        <div className="notifications">
          <p>Overdue Communications and Today’s Communications</p>
        </div>
  
        <h2>Calendar View</h2>
        <div className="calendar-view">
          <p>Past and Upcoming Communications</p>
        </div>
      </div>
    );
  }