import React, { useEffect, useState } from 'react';

const Admin = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch('http://localhost:5000/companies')
      .then(response => response.json())
      .then(data => setData(data))
      .catch(error => console.error('Error fetching data:', error));
  }, []);

  return (
    <div>
      <h1>Admin Page</h1>
      <ul>
        {data.map(company => (
          <li key={company.id}>{company.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default Admin;
