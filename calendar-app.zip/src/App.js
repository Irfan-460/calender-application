import AdminModule from './components/AdminModule/AdminModule';
import './App.css';
import UserModule from './components/UserModule/UserModule';
import Nav from './components/Nav/Nav';
import { Routes, Route } from "react-router";
import Home from './components/Home/Home';
import Form from './components/Form/Form';

function App() {
  return (
    <div className="App">
      <Nav />
      <Routes>
        <Route index element={<Home />} />
        <Route path="/admin" element={<Form />} />
        {/* <Route path='/test' element={<AdminModule/>}/> */}
        <Route path="/user" element={<UserModule />} />
      </Routes>
    </div>
  );
}

export default App;
